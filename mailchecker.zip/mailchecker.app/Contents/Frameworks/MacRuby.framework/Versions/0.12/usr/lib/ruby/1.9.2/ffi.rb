# The FFI Ruby API is implemented in MacRuby core, this file exists for compatibility with the others
# Ruby implementations.
